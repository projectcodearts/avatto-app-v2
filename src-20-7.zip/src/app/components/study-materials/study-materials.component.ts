import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-study-materials',
  templateUrl: './study-materials.component.html',
  styleUrls: ['./study-materials.component.scss'],
})
export class StudyMaterialsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
