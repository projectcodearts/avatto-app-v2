import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practice-question',
  templateUrl: './practice-question.page.html',
  styleUrls: ['./practice-question.page.scss'],
})
export class PracticeQuestionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
