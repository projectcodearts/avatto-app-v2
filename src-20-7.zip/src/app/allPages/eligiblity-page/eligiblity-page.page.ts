import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligiblity-page',
  templateUrl: './eligiblity-page.page.html',
  styleUrls: ['./eligiblity-page.page.scss'],
})
export class EligiblityPagePage implements OnInit {

  title:string = "Eligiblity";
  constructor() { }

  ngOnInit() {
  }

}
