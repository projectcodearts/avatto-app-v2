import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-syllabus-details',
  templateUrl: './syllabus-details.page.html',
  styleUrls: ['./syllabus-details.page.scss'],
})
export class SyllabusDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
